﻿using UnityEngine;
using System.Collections;

public class EnemyCube : MonoBehaviour {
	public float enemyHp = 3;
	public GameObject victim;
	public Transform lethalVertex;
	public Vector3 enemyVec;
	public int scoreValue;
	public GlobalGameLogic gameLogicThing;
	public GameObject victimCollider;
	public float enemySpeed = 1.0f;
	public float fireRate = 3.0f;
	public bool retreat = false;
	public AudioClip deathSound;
	//GameObject gameLogicObject;
	// Use this for initialization


	void Start () 
	{
	
	}

	// Update is called once per frame
	void Update () 
	{

		if (retreat == true && Time.time > fireRate)
		{
			particleSystem.startColor = (Color.red);
			enemySpeed = 4.0f;
		}
		if (lethalVertex == null)
		{
			gameObject.SetActive(false);;
		}
		if (enemyHp == 0)
		{
			audio.PlayOneShot(deathSound);
			gameLogicThing.AddKill (1);
			//gameLogicThing.RemoveSpawn (1);
			gameLogicThing.AddScore (scoreValue);
			Destroy (gameObject);
		}

		if (enemyHp < 0)
		{
			audio.PlayOneShot(deathSound);
			gameLogicThing.AddKill (1);
			//gameLogicThing.RemoveSpawn (1);
			gameLogicThing.AddScore (scoreValue);
			Destroy (gameObject);
		}



		Vector3 temp = victim.transform.position;
		temp.z = 0;
		
		
		Vector3 relativePos = temp - transform.position;
		relativePos.Normalize();
		Quaternion rotation = Quaternion.FromToRotation (Vector3.up, relativePos);
		
		transform.rotation = rotation;

		//vector between us
		Vector3 dif = lethalVertex.position - transform.position;
		
		//dist between us
		//float dist = dif.magnitude;
		
		//speed we could travel
		//float curSpeed = speed * dist * scaleRate * Time.deltaTime;
		
		transform.position += dif.normalized * enemySpeed * Time.deltaTime;
		//more movetowards
	}


	void OnTriggerEnter(Collider other) 
	{
		if (other.tag == "Shiggy")
		{
			audio.PlayOneShot(deathSound);
			enemyHp = enemyHp -1;
		}

		if (other.tag == "Explode")
		{
			Destroy (gameObject);
		}

		if (other.tag == "Detect" && Time.time > fireRate) 
		{

			retreat = true;
			fireRate = Time.time + 3.0f;
			enemySpeed = -1.0f;

		}

		if (other.tag == "Player")
		{
			Destroy(gameObject);
		}
			//enemyHp = enemyHp -1;

		//}
		//if (enemyHp == 0)
		//{
			//gameLogicThing.RemoveSpawn (1);
			//gameLogicThing.AddScore (scoreValue);
			//Destroy (gameObject);
		//}
		
	}
}
