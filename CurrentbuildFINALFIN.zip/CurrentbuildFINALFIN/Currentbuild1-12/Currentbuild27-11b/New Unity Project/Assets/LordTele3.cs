﻿using UnityEngine;
using System.Collections;

public class LordTele3 : MonoBehaviour {
	
	public GameObject activeTurret;
	public GlobalGameLogic gameLogicThing;
	
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
		if(gameLogicThing.teleCount2 == 2)
		{
			
			activeTurret.SetActive(true);
			
		}
		
	}
}