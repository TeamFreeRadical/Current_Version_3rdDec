﻿using UnityEngine;
using System.Collections;

public class Detectthing : MonoBehaviour {
	public float speedBull;
	public Vector3 vectorBull;
	
	// Use this for initialization
	void Start () 
	{
		vectorBull.x = 0;//transform.rotation.x;
		vectorBull.y = speedBull;
		vectorBull.z = 0;
		rigidbody.AddRelativeForce (vectorBull,ForceMode.Impulse);
	}
	
	void OnTriggerEnter(Collider other) 
	{
		if(other.tag == "Enemy")
		{
		Destroy (gameObject);
		}

		if(other.tag == "Wall")
		{
			Destroy (gameObject);
		}
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
