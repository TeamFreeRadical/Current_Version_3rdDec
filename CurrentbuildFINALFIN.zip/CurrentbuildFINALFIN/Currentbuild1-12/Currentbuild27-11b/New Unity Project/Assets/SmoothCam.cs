﻿using UnityEngine;
using System.Collections;

public class SmoothCam : MonoBehaviour {

	public Transform target;
	public float speed, scaleRate;

	
	public void FixedUpdate()
	{ 

		//vector between us
		Vector3 dif = target.position - transform.position;
		
		//dist between us
		float dist = dif.magnitude;
		
		//speed we could travel
		float curSpeed = speed * dist * scaleRate * Time.deltaTime;
		
		transform.position += dif.normalized * curSpeed;
		//more movetowards
	}
}
