﻿using UnityEngine;
using System.Collections;

public class LordShooot : MonoBehaviour {

	public Rigidbody missileLord;
	public GameObject cannon;
	public float shootCd;
	//public float bulletSpeed = 0;
	
	// Use this for initialization
	void Start () 
	{
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		
		shootCd -= Time.deltaTime;
		if(shootCd <= 0.0f )
		{
			Rigidbody bulletInstance;
			bulletInstance = Instantiate(missileLord, cannon.transform.position,cannon.transform.rotation) as Rigidbody;
			shootCd += 3;
		}
	}
}
