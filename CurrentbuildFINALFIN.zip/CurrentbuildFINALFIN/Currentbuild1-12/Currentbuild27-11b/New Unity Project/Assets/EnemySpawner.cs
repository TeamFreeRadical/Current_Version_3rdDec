﻿using UnityEngine;
using System.Collections;

public class EnemySpawner : MonoBehaviour 
{
	public Rigidbody enemyToSpawn;
	public GameObject spawnLocation;
	public float nextSpawn = 0.5f;
	public float untilSpawn = 0.5f;
	public float spawnCount = 0;
	public float killCount;
	public GameObject lordSpawn;
	public bool shouldSpawn = false;
	public bool spawnTrigger = false;
	public GameObject spawnSphere;
	//public float spawnCount = 5;
	//public float spawnTimerMax = 10;
	//public float spawnTimer = 1;
	// Use this for initialization

	public GlobalGameLogic enemyLogic;

	void Start () 
	{

	
	}

	// Update is called once per frame
    void Update () 
	{
		if (spawnCount >= 8)
		{
			shouldSpawn = false;
		}

		if (untilSpawn < -10.0f)
		{
			untilSpawn = 0.5f;
		}
		if (spawnTrigger == true && spawnCount <= 4)
		{
			shouldSpawn = true; 
		}

		//killCount = GlobalGameLogic.KillCount;
		//spawnCount = GlobalGameLogic.enemyCount;
		untilSpawn -= Time.deltaTime;
		if(untilSpawn <= 0.0f && shouldSpawn == true && spawnCount <= 4)		
		{
			spawnCount = spawnCount +1;
			untilSpawn =+ nextSpawn;
			Rigidbody enemyInstance;
			enemyInstance = Instantiate(enemyToSpawn, spawnLocation.transform.position,spawnLocation.transform.rotation) as Rigidbody;
			//GlobalGameLogic.enemyCount++;
		}
	}

	void OnTriggerEnter (Collider other)
	{
		if(other.tag == "Player")
		{
			spawnTrigger = true;
			//shouldSpawn = true;
		}
		
	}
}
